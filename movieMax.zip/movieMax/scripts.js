const API_KEY = 'c45a857c193f6302f2b5061c3b85e743';
const BASE_URL = 'https://api.themoviedb.org/3';
const IMG_BASE_URL = 'https://image.tmdb.org/t/p/w500';

$(document).ready(function() {
    loadMovies('popular', 1);

    $('#popularLink').click(function(e) {
        e.preventDefault();
        loadMovies('popular', 1);
    });

    $('#topRatedLink').click(function(e) {
        e.preventDefault();
        loadMovies('top_rated', 1);
    });

    $('#upcomingLink').click(function(e) {
        e.preventDefault();
        loadMovies('upcoming', 1);
    });

    $('#searchBtn').click(function() {
        const query = $('#search').val();
        if (query) {
            searchMovies(query, 1);
        }
    });
});

function loadMovies(type, page) {
    $.ajax({
        url: `${BASE_URL}/movie/${type}?api_key=${API_KEY}&language=en-US&page=${page}`,
        method: 'GET',
        success: function(response) {
            displayMovies(response.results);
            setupPagination(response.total_pages, page, type);
        },
        error: function(error) {
            console.error('Error fetching movies:', error);
        }
    });
}

function searchMovies(query, page) {
    $.ajax({
        url: `${BASE_URL}/search/movie?api_key=${API_KEY}&language=en-US&query=${query}&page=${page}`,
        method: 'GET',
        success: function(response) {
            displayMovies(response.results);
            setupPagination(response.total_pages, page, 'search', query);
        },
        error: function(error) {
            console.error('Error searching movies:', error);
        }
    });
}

function displayMovies(movies) {
    $('#content').empty();
    movies.forEach(movie => {
        const movieCard = `
            <div class="col-md-3 movie-card" onclick="loadMovieDetails(${movie.id})">
                <img src="${IMG_BASE_URL}${movie.poster_path}" alt="${movie.title}" class="img-fluid">
                <h5>${movie.title}</h5>
                <p>Rating: ${movie.vote_average}</p>
            </div>
        `;
        $('#content').append(movieCard);
    });
}

function loadMovieDetails(movieId) {
    $.ajax({
        url: `${BASE_URL}/movie/${movieId}?api_key=${API_KEY}&language=en-US`,
        method: 'GET',
        success: function(movie) {
            displayMovieDetails(movie);
            loadMovieCast(movieId);
        },
        error: function(error) {
            console.error('Error fetching movie details:', error);
        }
    });
}

function displayMovieDetails(movie) {
    $('#content').empty();
    const movieDetails = `
        <div class="movie-details row">
            <div class="col-md-4">
                <img src="${IMG_BASE_URL}${movie.poster_path}" alt="${movie.title}" class="img-fluid">
            </div>
            <div class="col-md-8">
                <h2>${movie.title}</h2>
                <p>${movie.overview}</p>
                <p>Release Date: ${movie.release_date}</p>
                <p>Rating: ${movie.vote_average}</p>
            </div>
        </div>
    `;
    $('#content').append(movieDetails);
}

function loadMovieCast(movieId) {
    $.ajax({
        url: `${BASE_URL}/movie/${movieId}/credits?api_key=${API_KEY}&language=en-US`,
        method: 'GET',
        success: function(credits) {
            displayMovieCast(credits.cast);
        },
        error: function(error) {
            console.error('Error fetching movie cast:', error);
        }
    });
}

function displayMovieCast(cast) {
    const castContainer = $('<div class="movie-cast row"></div>');
    cast.forEach(actor => {
        const actorCard = `
            <div class="actor-card col-md-2">
                <img src="${IMG_BASE_URL}${actor.profile_path}" alt="${actor.name}" class="img-fluid">
                <p>${actor.name}</p>
            </div>
        `;
        castContainer.append(actorCard);
    });
    $('#content').append(castContainer);
}

function setupPagination(totalPages, currentPage, type, query = '') {
    $('#pagination').empty();
    const paginationNav = $('<nav></nav>');
    const paginationUl = $('<ul class="pagination justify-content-center"></ul>');

    for (let i = 1; i <= totalPages; i++) {
        const pageItem = $(`<li class="page-item ${i === currentPage ? 'active' : ''}"></li>`);
        const pageLink = $(`<a class="page-link" href="#">${i}</a>`);
        pageLink.click(function(e) {
            e.preventDefault();
            navigatePage(type, i, query);
        });
        pageItem.append(pageLink);
        paginationUl.append(pageItem);
    }

    paginationNav.append(paginationUl);
    $('#pagination').append(paginationNav);
}

function navigatePage(type, page, query) {
    if (type === 'search') {
        searchMovies(query, page);
    } else {
        loadMovies(type, page);
    }
}
